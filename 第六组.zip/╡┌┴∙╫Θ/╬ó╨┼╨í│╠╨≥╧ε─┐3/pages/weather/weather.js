// pages/weather/weather.js
Page({

  /**
   * 页面的初始数据
   */
  data: {
    city: '',
    weather: '',
    temp: '',
    wind: '',
    pic: '',
    pm25: ''
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (e) {
    // console.log(e)
    // return;
    var that = this
    //console.log(that.data);
    var city = e.city
    //console.log(options.city)

    // console.log(this.data)

    //var defaultcity = e.city

    wx.request
      ({
        url: 'https://api.map.baidu.com/telematics/v3/weather',

        data: {
          output: 'json',
          ak: '1a3cde429f38434f1811a75e1a90310c',
          location: city
        },


        success: function (res) {
          //console.log(res);
          // return;

          var getweather = res.data.results[0].weather_data[0].weather
          var gettemp = res.data.results[0].weather_data[0].temperature
          var getwind = res.data.results[0].weather_data[0].wind
          var getpic = res.data.results[0].weather_data[0].dayPictureUrl
          var getpm25 = res.data.results[0].pm25

          var tweather = res.data.results[0].weather_data[1].weather


          that.setData
            ({
              city: city,
              weather: getweather,
              temp: gettemp,
              wind: getwind,
              pic: getpic,
              pm25: getpm25,
              tweather: tweather
            })

          console.log(that.data);
          //return
        }
      })



  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})