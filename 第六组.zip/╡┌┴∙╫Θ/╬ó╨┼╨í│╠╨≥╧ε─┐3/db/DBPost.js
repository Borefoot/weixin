var util=require('../util/util.js')
class DBPost {
  constructor(postId) {
    this.storageKeyName = 'postList';
    this.postId = postId;
  }

  getAllPostData() {
    var res = wx.getStorageSync(this.storageKeyName);
    if (!res) {
      res = require('../data/data.js').postList;
      this.initPostList(res);
    }
    return res;
  }

  execSetStorageSync(data){
    wx.setStorageSync(this.storageKeyName, data);
  }

  getPostItemById() {
    var postsData = this.getAllPostData();
    var len = postsData.length;
    for (var i = 0; i < len; i++) {
      if (postsData[i].postId == this.postId) {
        return {
          index: i,
          data: postsData[i]
        }
      }
    }
  }

  collect(){
    return this.updataPostData('collect');
  }

  updataPostData(category){
    var itemData=this.getPostItemById(),
      postData=itemData.data,
      allPostData=this.getAllPostData();
    switch(category){
      case'collect':
        if(!postData.collectionStatus){
          postData.collectionNum++;
          postData.collectionStatus=true;
        }
        else{
          postData.collectionNum--;
          postData.collectionStatus=false;
        }
        break;
      case 'up':
        if (!postData.upStatus) {
          postData.upNum++;
          postData.upStatus = true;
        }
        else {
          postData.upNum--;
          postData.upStatus = false;
        }
        break;
      case'reading':
        postData.readingNum++;
        break;
      default:
        break;
    }
    allPostData[itemData.index]=postData;
    this.execSetStorageSync(allPostData);
    return postData;
  }

  up(){
    var data=this.updataPostData('up');
    return data;
  }

  getCommentData(){
    var itemData=this.getPostItemById().data;
    itemData.comments.sort(this.compareWithTime);
    var len=itemData.comments.length,
      comment;
    for(var i=0; i<len; i++){
      comment=itemData.comments[i];
      comment.create_time=util.getDiffTime(comment.create_time,true);
    }
    return itemData.comments;
  }

  compareWithTime(value1, value2){
    var flag=parseFloat(value1.create_time)-parseFloat(value2.create_time);
    if(flag<0){
      return 1;
    }
    else if(flag>0){
      return -1;
    }
    else{
      return 0;
    }
  }

  addReadingTimes(){
    this.updataPostData('reading')
  }


};
export { DBPost }