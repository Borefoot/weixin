var postList = [{
  date: "Jan 28 2017",
  title: "小时候爷爷的茶壶",
  postImg: "/images/1.jpg",
  avatar: "/images/avatar/1.png",
  content: "小时候爷爷的茶壶...",
  readingNum: 325,
  collectionNum:122,
  commentNum: 12,
  author: "林白衣",
  dateTime: "24小时前",
  detail: "小时候爷爷泡的茶，小时候爷爷泡的茶",
  postId: 1,
  music: {
    url: "http://ws.stream.qqmusic.qq.com/C100001Dc80Z3qPj2Z.m4a?fromtag=38",
    title: "罗大佑 恋曲1980",
    coverImg: "http://y.gtimg.cn/music/photo_new/T002R150x150M000003cWU1M2qNwxZ.jpg?max_age=2592000",
  },
  collectionStatus: true,
  upStatus: false,
  upNum: 11,
  comments: []
},
{
  date: "Oct 2 2018",
  title: "傍晚的船",
  postImg: "/images/2.jpg",
  avatar: "/images/avatar/2.png",
  content: "傍晚的船...",
  readingNum: 3245,
  collectionNum: 1432,
  commentNum: 1233,
  author: "章帅哥",
  dateTime: "24小时前",
  detail: "傍晚的船，傍晚的船",
  postId: 2,
  music: {
    url: "http://ws.stream.qqmusic.qq.com/C100004VybKS2SpZVL.m4a?fromtag=38",
    title: "齐秦 原来的我",
    coverImg: "http://y.gtimg.cn/music/photo_new/T002R150x150M000003ZvAeK2PgA4Y.jpg?max_age=2592000"
  },
  collectionStatus: true,
  upStatus: true,
  upNum: 22,
  comments: [
    {
      username: '青石',
      avatar: '/images/avatar/avatar-3.png',
      create_time: '1484723344',
      content: {
        txt: ' 那一年的毕业季，我们挥挥手，来不及说再见，就踏上了远行的火车。',
        img: ["/images/comment/train-1.jpg", "/images/comment/train-2.jpg", "/images/comment/train-3.jpg"],
        audio: null
      }
    }, {
      username: '水清',
      avatar: '/images/avatar/avatar-2.png',
      create_time: '1481018319',
      content: {
        txt: '夏日的蝉鸣与夜晚的火车，时长会在未来无数的日子里不断的在我耳边响起，难以忘怀',
        img: [],
        audio: null,
      }
    },
    {
      username: '赤墨',
      avatar: '/images/avatar/avatar-1.png',
      create_time: '1484496000',
      content: {
        txt: '时光的湮染，自然的吞噬，让太多的老火车站也消失得无影无踪',
        img: ["/images/comment/train-4.jpg",],
        audio: null,
      }
    },
    {
      username: '林白',
      avatar: '/images/avatar/avatar-4.png',
      create_time: '1484582400',
      content: {
        txt: '',
        img: [],
        audio: { url: "http://123", timeLen: 8 },
      }
    }
  ]
},
{
  date: "Oct 7 2018",
  title: "通往香格里拉的铁路",
  postImg: "/images/3.jpg",
  avatar: "/images/avatar/3.png",
  content: "通往香格里拉的铁路...",
  readingNum: 142,
  collectionNum: 345,
  commentNum: 133,
  author: "卢本伟",
  dateTime: "24小时前",
  detail: "通往香格里拉的铁路...",
  postId: 3,
  music: {
    url: "http://ws.stream.qqmusic.qq.com/C100003XYcCu3IZKLc.m4a?fromtag=38",
    title: "老狼 虎口脱险",
    coverImg: "http://y.gtimg.cn/music/photo_new/T002R150x150M000002sNbWp3royJG.jpg?max_age=2592000"
  },
  collectionStatus: false,
  upStatus: false,
  upNum: 9,
  comments: []
},
]

module.exports = {
    postList: postList
}